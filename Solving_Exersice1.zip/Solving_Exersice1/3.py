c1,c2,c3=input('enter three color and seprate with , : ').split(',')
if c1==c2==c3:
    print('three colors are same')
elif c1==c2 or c1==c3 or c2==c3:
    print('two colors are same')
else:
    print('not math!')