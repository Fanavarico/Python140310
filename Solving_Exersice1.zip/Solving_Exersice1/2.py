'''s=input('enter string : ')
#v='aeiouAEIOU'
v=['a','e','i','o','u','A','E','I','O','U']
c=0
for i in s:
    if i in v:
        c+=1
        
print(c)'''

s=input('enter string : ').lower()
#v='aeiou'
v=['a','e','i','o','u']
c=0
for i in s:
    if i in v:
        c+=1
        
print(c)