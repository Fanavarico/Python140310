
import tkinter
from tkinter import Button
from tkinter import messagebox
import random
m=tkinter.Tk()
choice=''
def btnrock():
 choice="rock"
 choice_random=random.choice(['rock','paper','scissors']) 
 if choice==choice_random:
     msg=messagebox.showinfo('answer',"Very equal   choice you:{} choice computer:{}".format(choice,choice_random))
 elif choice=='rock' and choice_random =='scissors':
      msg=messagebox.showinfo('answer',"you won  choice you:{} choice computer:{}".format(choice,choice_random))
 elif choice=='rock' and choice_random=='paper':
        msg=messagebox.showinfo('answer',"you lost  choice you:{} choice computer:{}".format(choice,choice_random))
    
def btnpaper():
 choice="paper"
 choice_random=random.choice(['rock','paper','scissors']) 
 if choice==choice_random:
     msg=messagebox.showinfo('answer',"Very equal  choice you:{} choice computer:{}".format(choice,choice_random))
 elif choice_random=='paper' and choice=='rock':
      msg=messagebox.showinfo('answer',"you won  choice you:{} choice computer:{}".format(choice,choice_random))
 elif choice=='paper' and choice_random=='scissors':
        msg=messagebox.showinfo('answer',"you lost  choice you:{} choice computer:{}".format(choice,choice_random))
    
def btnscissors():
 choice="scissors"
 choice_random=random.choice(['rock','paper','scissors']) 
 if choice==choice_random:
     msg=messagebox.showinfo('answer',"Very equal choice you:{} choice computer:{}".format(choice,choice_random))
 elif choice=='scissors' and choice_random=='paper':
      msg=messagebox.showinfo('answer',"you won  choice you:{} choice computer:{}".format(choice,choice_random))
 elif choice=='scissors' and choice_random=='rock':
        msg=messagebox.showinfo('answer',"you lost choice you:{} choice computer:{}".format(choice,choice_random))
        
m.minsize(width=700,height=300)
m.minsize(width=700,height=300)
rock_button=Button(m,width="12",height="3",text='rock/سنگ',bg='Green',font=10,command=btnrock)
rock_button.place(x='100',y='100')
paper_button=Button(m,width='12',height='3',text='paper/کاغذ',bg='Blue',font=10, command=btnpaper)
paper_button.place(x='300',y='100')
scissors_button=Button(m,width="12",height="3",text='scissors/قیچی',bg='Yellow',font=10,command=btnscissors)
scissors_button.place(x='500',y='100')

    
    
rock_button.mainloop()
paper_button.mainloop()
scissors_button.mainloop()
m.mainloop()
