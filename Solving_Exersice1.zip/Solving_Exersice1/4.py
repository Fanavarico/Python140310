a=1
b=1
while a<10:
    print(a)
    a,b=b,a+b
    