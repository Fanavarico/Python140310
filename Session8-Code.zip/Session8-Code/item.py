class Item:
    def __init__(self,id_i,name,price,number):
        self.id_i=id_i
        self.name=name
        self.price=price
        self.number=number
    
    def __str__(self):
        return f'name: {self.name},id: {self.id_i},price: {self.price},numner: {self.number}'

if __name__=='__main__':
    i1=Item(10, 'n1', 100, 10)
    print(i1)
