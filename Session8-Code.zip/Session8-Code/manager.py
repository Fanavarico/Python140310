from item import *
class InventoryManager:
    def __init__(self):
        self.items={}
    def create_item(self,id_i,name,price,number):
        new_item=Item(id_i, name, price, number)
        return new_item
    def add_item(self,item):
        if item.id_i not in self.items:
            self.items[item.id_i]=item
            print('added')
        else:
            print('exists')
    def remove_item(self,id_i):
        if id_i in self.items.keys():
            del self.items[id_i]
            print('removed')
        else:
            print('not found')
    def dispaly_item(self,id_i):
        if id_i in self.items.keys():
    
            print(self.items[id_i])
        else:
            print('id not found')
    def edit_item(self,id_i):
        if id_i in self.items:
            
            n_name=input('enter new name:')
            n_price=input('enter new price')
            n_number=input('enter new number : ')
            self.items[id_i].name=n_name or self.items[id_i].name
            self.items[id_i].price=int(n_price or self.items[id_i].price) 
            self.items[id_i].number=int(n_number or self.items[id_i].number)
        else:
            print('can not edit , not found')
    def __str__(self):
        return f'{self.items}'
    def search_item(self,name):
        for item in self.items.values():
            if item.name==name:
                print(item)
    
i2=InventoryManager()
item1=i2.create_item(14, 'n8', 1000,7)
item2=i2.create_item(1, 'n80', 10100,70)
i2.add_item(item1)
i2.add_item(item2)
#print(i2.items)
#i2.remove_item(100)
#print(i2.items)

i3=InventoryManager()
item100=i3.create_item(1000, 'n100', 1000, 2)
item200=i3.create_item(2000, 'n100', 2000, 6)
item300=i3.create_item(3000, 'n300', 3000, 15)
i3.add_item(item100)
i3.add_item(item200)
i3.add_item(item300)
#print('i3: ',i3)
#print('i2: ',i2)

#i2.edit_item(12)
#i2.dispaly_item(14)
i3.search_item('n100')