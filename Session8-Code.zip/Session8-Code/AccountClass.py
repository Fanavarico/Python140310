class Account:
    def __init__(self,balance,owner):
        self.balance=balance
        self.owner=owner
        
    def deposite(self,amount):
        self.balance+=amount
        return self.balance
    def withdraw(self,amount):
        if self.balance<amount:
            return 'poolet kame'
        else:
            
            self.balance-=amount
        return self.balance
    
    