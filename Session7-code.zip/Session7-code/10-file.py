ad='C:\\Users\\EZ-Tech\\Desktop\\first.txt'
with open(ad,encoding='utf-8') as fr
with open(ad,encoding='utf-8') as fr:
    for i in fr:
        print(i)
