class Test:
    def __init__(self,x,y):
        self.n1=x
        self.n2=y
    def jam(self):
        return self.n1+self.n2
    def zarb(self):
        return self.n1*self.n2

a=int(input('first :'))
b=int(input('second :'))
obj1=Test(a,b)
print(obj1.jam())

