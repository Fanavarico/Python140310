try:
    a:'ali'
    print(a)
except Exception as e:
    print(e)

