s='a'
print(type(s))
