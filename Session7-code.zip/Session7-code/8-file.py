#ad='C:\\Users\\EZ-Tech\\Desktop\\first.txt'
ad='C:\\Users\\EZ-Tech\\Desktop\\first.txt'
with open(ad,'a',encoding='utf-8') as fw:
    l1='سلام آوا'
    l2='hello ali'
    fw.write('\n')
    fw.write(l1)
    fw.write('\n')
    fw.write(l2)

