ad1='C:\\Users\\EZ-Tech\\Desktop\\first.txt'
ad2='C:\\Users\\EZ-Tech\\Desktop\\second.txt'
with open(ad1,'w') as fw1:
    l1='hello ali'
    l2='hello ava'
    fw1.write(l1)
    fw1.write('\n')
    fw1.write(l2)
    fw1.write('\n')

with open(ad2,'w') as fw2:
    l1='hello reza'
    l2='hello hassan'
    fw2.write(l1)
    fw2.write('\n')
    fw2.write(l2)
