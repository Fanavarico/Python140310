import file
ad3='C:\\Users\\EZ-Tech\\Desktop\\third.txt'

with open(ad3,'w') as fw3:
    fw3.write(file.data)
