a=int(input('first'))
b=int(input('second:'))
try:
    c=a/b
    print(c)
except Exception as e:
    print(e)
#except ZeroDivisionError as ze:
#   print(ze)
print('hello')
