try:
    x=8/8
except ZeroDivisionError as ze:
    print(ze)
else:
    print(x)
print('hello')

