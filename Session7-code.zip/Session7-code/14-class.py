class Test:
    def set_var(self,n1,n2):
        self.n1=n1
        self.n2=n2
    def jam(self):
        return self.n1+self.n2
    def zarb(self):
        return self.n1*self.n2

obj1=Test()
obj1.
obj1.set_var(5,9)
print('obj1',obj1.jam())
obj2=Test()
obj2.set_var(3,7)
print('obj2:',obj2.jam())
print(obj2.n1)

