ad='C:\\Users\\EZ-Tech\\Desktop\\first.txt'
with open(ad,'w') as fw:
    l1='hello python'
    l2='hello java'
    fw.write(l1)
    fw.write('\n')
    fw.write(l2)
