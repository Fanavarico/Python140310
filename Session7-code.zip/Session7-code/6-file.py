f=open('C:\\Users\\EZ-Tech\\Desktop\\first.txt','w')
f.write('salam ava')
f.close()