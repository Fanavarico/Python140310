s='ali'
try:
    print(a)
    s.append('a')
    
except Exception as e:
    print(e)
#except AttributeError as ae:
#    print(ae)
print('hello')
