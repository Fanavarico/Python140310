try:
    x=8/0
except ZeroDivisionError as ze:
    print(ze)
else:
    print(x)
finally:
    print('bye')
print('hello')


