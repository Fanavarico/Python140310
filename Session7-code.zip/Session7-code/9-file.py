ad='C:\\Users\\EZ-Tech\\Desktop\\first.txt'
with open(ad,encoding='utf-8') as fr:
    #c=fr.read(14)
    #c=fr.readline(100)
    c=fr.readlines()
    '''
    l=[]
    for i in c:
        #i=i.strip()
        i=i.replace('\n','')
        l.append(i)'''
    c=[i.strip() for i in c]
    print(c)