y=int(input('enter year :'))
e=input('enter event : ')
print(f'thin event {e} was happened in {y}')

