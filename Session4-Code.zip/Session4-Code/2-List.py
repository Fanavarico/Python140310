l=[4,15]
#print(l*3)
l1=[100,200]
print(l1+l)
