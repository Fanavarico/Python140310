#l=[12,15,500,False,12,5,120,14,False,0]
l=['hassan','Ava','ali','ava','Ali','112']
#c=l.count(False)
#c=l.count(12)
#print(c)
#l.insert(2, 'hassan')
#l.remove(False)
#l.remove(False)
#t=l.pop()
#print(t)
#l.clear()
#del l
#l.reverse()
#l.sort()

print(l)

