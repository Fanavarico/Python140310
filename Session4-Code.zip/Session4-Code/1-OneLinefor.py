'''l=[]
for _ in range(1,5):
    s=input('enter')
    l.append(s)
    
print(l)'''
#s=input('enter')
#l=[input('enter') for _ in range(1,5)]
#l=[i*2 for i in range(0,4)]
#l=[i for i in range(0,7,2)]

#print(l)
#[0,2,4,6]

