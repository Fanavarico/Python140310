l=['$ali','sara$']
#l=['ali','sara']
h=[i.strip('$') for i in l]
print(h)