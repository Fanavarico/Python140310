'''a=input('first')
b=input('second')
c=input('third')
a,b,c=12,'ali',9.9
print('a',a)
print('b',b)
print('c',c)'''
a,b,c=input('enter ').split(',')
'''
print('a',a)
print('b',b)
print('c',c)'''
print('a',a,'b',b,'c',c)


