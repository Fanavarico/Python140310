l=[12,15,500,5,120,14,1]
s=0
for i in l:
    if i%2==1:
        s+=i
        
print(s)
        