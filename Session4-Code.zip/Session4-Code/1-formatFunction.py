n=input('enter fullname : ')
c=int(input('enter class number : '))

#print('{1} studied in {0} class'.format(c,n))
print('%s studied in %i class'%(n,c))
