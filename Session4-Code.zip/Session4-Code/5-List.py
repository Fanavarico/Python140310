l=[]
'''for i in range(1,5):
    s=input('enter')
    l.append(s)
    
print(l)'''
a,b,c,d=input('enter : ').split(',')
#print(type((a,b,c,d)))
l.extend([a,b,c,d])
print(l)

