i=15
j=13
#print('{:.2f}'.format(i))
print('{0:d},{1:.3f}'.format(i,j))
