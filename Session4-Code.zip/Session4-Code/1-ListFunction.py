l=[12,12.5,True,'n1',12,'n1']
#print(len(l))
#i=l.index('n1',5)

#print(l[1])
