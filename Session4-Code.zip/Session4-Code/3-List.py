l=[12,15,500,120,14]
'''m=-100
for i in l:
    if i>m:
        m=i
        print(m)'''
        
#print(max(l))
#print(min(l))
'''s=0
for i in l:
    s+=i
    
print(s)'''
print(sum(l))
    