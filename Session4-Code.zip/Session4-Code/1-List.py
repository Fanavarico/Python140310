l=[12,12.5,True,'n1',12,'n1']
'''
for i in l:
    print(i,end=' ')'''

for i in range(len(l)):
    print(l[i])

