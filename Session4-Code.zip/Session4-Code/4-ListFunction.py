l=['hassan','Ava','ali','ava','Ali','112']
l.extend(('12',))
#l.append(['ali',12])
print(len(l))
print(l)