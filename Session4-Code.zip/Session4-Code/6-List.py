l=[]
while True:
    s=input('enter :')
    if s.lower()=='exit':
        break
    elif s.isdigit():
        s=int(s)
    l.append(s)
    

print(l)