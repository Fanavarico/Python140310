s='python.is.high.level.language'
#f=s.replace('p','j',1)
#f=s.lstrip('$')
#f=s.strip('$')
#f=s.replace('$','')
#f=s.lstrip('#').rstrip('$')
#f=s.split('.')
l=['python', 'is', 'high', 'level', 'language']
f='\n'.join(l)
print(f)