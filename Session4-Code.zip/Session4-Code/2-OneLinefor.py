l=[12,-50,9,-13]
h=[abs(i) for i in l if i<0]
print(h)
