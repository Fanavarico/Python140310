d={'a':3,'c':10,'x':18}
#c=0
'''for i in d.values():
    c+=i

for i in d:
    c+=d[i]'''
print(sum(d.values()))
#print(c)