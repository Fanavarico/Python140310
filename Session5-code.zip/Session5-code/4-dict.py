d={'brand':'BMW','model':'i8','color':'white'}
#i=d.pop('brand')
#i=d.pop('brand')
#i=d.popitem()
#d.clear()
#print(i)
#del d
print(d)