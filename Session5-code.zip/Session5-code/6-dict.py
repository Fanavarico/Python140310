w='python is high level language , python is '
l=w.split()
#print(l)
d={}
for i in l:
    if i not in d:
        d[i]=1
    elif i in d:
        d[i]+=1
        
        
print(d)