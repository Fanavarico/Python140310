s={'apple','orange','mango','grape','apple','Apple'}
#s.remove('apple')
#s.discard('applee')
#i=s.pop()
#i=s.copy()
s.clear()
#print(i)
print(s)
