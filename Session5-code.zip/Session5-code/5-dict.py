#l=['x','y','a','x','x','a']
d={}
#d={'x':3,'y':1,'a':2}
'''for i in l:
    if i not in d:
        d[i]=1
    elif i in d:
        d[i]+=1
'''
s='hjgakjkajkaaaaa'
for i in s:
    d[i]=d.get(i,0)+1
print(d)