'''def hello():
    print('hello world')

u=hello()
print(u)'''

def hello(s):
    print('hello', s)

a=input('enter : ')
hello(a)
