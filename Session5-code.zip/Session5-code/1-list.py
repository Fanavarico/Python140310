s=[12,13,'a']
if 'to' in s:
    print(True)
else:
    print(False)