d1={'a':10,'b':19,'z':40}
d2={'x':1,'y':100,'z':40}
d={}
'''
d=d1.copy()
d.update(d2)
#d=d1.copy()
print(d)'''
for i in (d1,d2):
    d.update(i)
    
print(d)
