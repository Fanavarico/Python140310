a={1,2,3,4,5}
b=set()
print(a.isdisjoint(b))