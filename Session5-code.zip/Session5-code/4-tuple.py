l=[3,5,(9,),'p',('3',5),True]
c=0
for i in l:
    if isinstance(i,tuple):
        c+=1

print(c)