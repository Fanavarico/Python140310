stu={'a':[10,16,12],
     'b':[19,13,17],
     'c':[9,17,12]
     }

d={k:sorted(v) for k,v in stu.items()}
print(d)