d={'a':1,'b':2}
d1={'x':100,'y':10}
d1=d.copy()
print(d1)
