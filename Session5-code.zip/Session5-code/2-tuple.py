'''t=(4,6)
t1=(9,'a')
print(t+t1)'''
t=(4,6)
l=list(t)
#print(l)
l.append('a')
#print(l)
print(tuple(l))

