d={'brand':'BMW','model':'i8','color':'white'}
'''
for i in d.values():
    print(i)'''
'''
i=d.items()
print(type(i))
print(i)

for i in d:
    print(i,':',d[i])
    
for k,v in d.items():
    print(k,':',v)'''

  
