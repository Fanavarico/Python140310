d={'brand':'BMW','model':['i8','i9','i10'],'color':'white'}
for k,v in d.items():
    
    print(k,':',v)