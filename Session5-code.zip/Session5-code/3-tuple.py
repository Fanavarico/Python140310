#t=(2,4,5)
#t=[2,4,6]
t='ali'
a,b,c=t
print('a',a)
print('b',b)
print('c',c)
