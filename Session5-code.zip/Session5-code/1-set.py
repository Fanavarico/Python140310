s={'apple','orange','mango','grape','apple','Apple'}
s1={'mango','grape','apple','Apple','orange','grape','mango'}
#print(s1==s)
#print('cheery' in s)
#s.add((8,'a'))
s.update('3','ali')
print(s)