r=float(input('enter :'))
p=3.14
#a=r*r*p
print('masahat :',r*r*p)

