import os
f='C:\\Users\\EZ-Tech\\Desktop\\New folder (2)'
os.remove(f)

