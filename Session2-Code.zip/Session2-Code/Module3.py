import random
#print(random.randint(1, 5))

p=random.choice(['sang','ghaychi','kaghaz'])
print(p)
