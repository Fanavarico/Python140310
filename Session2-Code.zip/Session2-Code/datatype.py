#i='python'

#اولین برنامه

#b=False
#i='34'
#u=[12,4]
#i=13
#l=['78','java',True,9.7,60,['python',6],'java',60]
#t=('python',9,True,[12,'java'],9,True)
#s={'python',80,9,12,True,12,'java',80.9}
#d={'name':'ali','family':'rezaei','class':8,'name':'reza'}
#s='pythone'
#print(s[-1:-7:1])
#print(t[::-1])
#print(type(t))