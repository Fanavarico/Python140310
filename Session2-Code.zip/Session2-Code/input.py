i=int(input('enter : '))
print(type(i))
#print('hello',i)

