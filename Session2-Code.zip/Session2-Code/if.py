i=int(input('enter number :'))

if i>0:
    print(i,' is POS')
else:
    print(i,' is NEG')