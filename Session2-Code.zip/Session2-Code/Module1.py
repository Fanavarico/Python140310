import math
#t=float(input('enter :'))

#i=math.sqrt(t)
#i=math.log(t)
i=math.fmod(10, 3)

print(i)
print(type(i))