import math
i=int(input('enter : '))
if i>0:
    print(math.sqrt(i))
else:
    i=abs(i)
    print(math.sqrt(abs(i)))