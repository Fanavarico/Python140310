i=int(input('enter : '))
if i%2==0:
    print(i,' is even')
else:
    print(i,' is odd')
    

