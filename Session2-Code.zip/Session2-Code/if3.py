l=[12,13,8]
i=int(input('enter : '))
if i not in l:
    print('not found')
else:
    print('found')

