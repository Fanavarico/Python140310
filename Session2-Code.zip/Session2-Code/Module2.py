from datetime import datetime,timedelta
print(datetime.now()+timedelta(days=1))
