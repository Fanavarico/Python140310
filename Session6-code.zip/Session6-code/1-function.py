'''def hello():
    print('hello world')
    

def hello(s:str):
    this function has input
    print('hello ',s)

a=input('enter name :')
hello(a)

def hello():
    return f'hello world'

g=hello()
print(g)

def hello(s):
    return f'hello {s}'

a=input('enter name : ')
g=hello(a)
print(g)'''

def jam(a,b):
    return a+b
x=int(input('first : '))
y=int(input('second :'))
f=jam(x,y)
print(f)





