def f(lst):
    lst[0]+=1
    lst[1]-=1

l=[12,70]
f(l)
print(l)
