s='a'
print(s.replace('a','r'))
