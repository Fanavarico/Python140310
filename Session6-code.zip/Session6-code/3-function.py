p=3.14
def mo(r):
    
    return r*2*p

def ma(r):
    return r*r*p

def main():
    a=int(input('enter raduis : '))
    s=input('enter mohit or masahat : ')
    if s=='mohit':
        print(mo(a))
    elif s=='masahat':
        print(ma(a))

main()
