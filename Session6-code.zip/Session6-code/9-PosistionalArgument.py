def f(a,b):
    print(a,b)

#f(2,5)
#f(a=3,b=5)
#f(5,b=9)
#f(7,a=10)
#f(10,6)
#f(b=10,a=6)
#f(a=9,4)
