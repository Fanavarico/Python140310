def f(**l):
    l['avg']=(l.pop('m')+l.pop('f'))/2
    print(l)
    
for i in range(2):
    a=int(input('id'))
    b=int(input('m'))
    c=int(input('f'))
    f(id1=a,m=b,f=c)