def pal(s):
    print(s==s[::-1])

#pal('radar')
pal('gh')
