def f(m,a=7,b=8):
    print(m,a,b)
    
#f(b=5)
#f(a=10) 
#f()
f(90) 
  
