def f(**t):#kwarg
    print(t)
    
f()
f(name='ali')
f(name='ali',family='r',class1=8)

f(name='ali',family=['r','u'],class1=8)
