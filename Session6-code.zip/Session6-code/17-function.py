lst=[{'id':8,'m':20,'f':17},\
   {'id':20,'m':15,'f':18}]
#l=[{'id':8,'avg':18.5},{'id':20,'avg':16.5}]
def f(l:list):
    for i in l:
        m=i.pop('m')
        f=i.pop('f')
        i['avg']=(m+f)/2
    
    print(l)
f(lst)