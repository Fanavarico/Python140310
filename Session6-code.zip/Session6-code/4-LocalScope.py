x=90
def f():
    x=5
    print(x)

f()    
print(x)