a=input('enter :')
def f(s):
    d={'l':0,'u':0}
    
    for i in s:
        if i.islower():
            d['l']+=1
        elif i.isupper():
            d['u']+=1
        else:
            continue
    print(d)

f(a)
