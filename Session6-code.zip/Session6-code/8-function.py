def f(d):
    d['a']+=1
    d['b']-=1

h={'a':10,'b':8}
f(h)
print(h)
    

