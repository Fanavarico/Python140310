def f(*t):#args
    #print(t)
    return t
    
f()
f(5)
f(10,12,'ali')
f(14,True,45,7,9,9,15,15.4)
#h=f(10,12,'ali')
#print(list(h))
print(list(f(10,12,'ali')))
