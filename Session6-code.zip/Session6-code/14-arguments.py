def f(a,b,*t,**r):
    #print(a,b,t,r)
    print(list((a,b,t,r)))
    
#f()
f(3,6)
f(3,6,8)
f(3,6,8,name='ali')
