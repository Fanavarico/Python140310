x=9
def f():
    global x
    x=79
    print(x)
    
f()
print(x)
