a=input('enter :')
def f(s,**t):
    
    
    for i in s:
        if i.islower():
            t['l']+=1
        elif i.isupper():
            t['u']+=1
        else:
            continue
    print(t)
    
f(a,l=0,u=0)
