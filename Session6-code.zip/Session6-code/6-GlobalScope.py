x=7
def f():
    global x
    print(x)
    x=9
    print(x)
    
f()
print(x)
