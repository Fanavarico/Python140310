def m(a:int,b:int):
  
    ma=max(a,b)
    return ma
''' 
  if a>b:
      return a
  elif a<b:
      return b'''

'''
x=8
y=5
j=m(x,y)
print(j)'''

def g(x,y,z):
    return m(x,m(z,y))

f=g(12,3,14)
print(f)


