def add_data(var):
    print('hello')

def add_data(var1):
    print('salam')
    
add_data('3')
