from abc import ABC,abstractmethod
class Product(ABC):
    def __init__(self,name,price,number):
        self.name=name
        self.price=price
        self.number=number
    def __str__(self):
        return f'name:{self.name},price:{self.price},number:{self.number}'
    @abstractmethod
    def apply_discount(self):
        pass


class Book(Product):
    def __init__(self,name,price,number,author,pages):
        super().__init__(name,price,number)
        self.author=author
        self.pages=pages
    def __str__(self):
        return f'{super().__str__()},author:{self.author},pages:{self.pages}'
    
    def apply_discount(self):
        discount=self.price*(0.15)
        self.price-=discount
        return self.price
    

class Laptop(Product):
    def __init__(self,name,price,number,ram,cpu):
        super().__init__(name,price,number)
        self.ram=ram
        self.cpu=cpu
    def __str__(self):
        return f'{super().__str__()},ram:{self.ram},cpu:{self.cpu}'
    
    def apply_discount(self):
        discount=self.price*(0.05)
        self.price-=discount
        return self.price
    

b1=Book('b1',190,9,'a1',90)
print(b1)
b1.apply_discount()
print(b1)
l1=Laptop('n100', 1000, 5, 12, 'c1')
print(l1)
l1.apply_discount()
print(l1)