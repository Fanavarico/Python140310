from abc import ABC,abstractmethod
class MyClass(ABC):
    @abstractmethod
    def my_method(self):
        pass
mc=MyClass()
