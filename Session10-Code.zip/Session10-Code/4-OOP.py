
class Product:
    def __init__(self,name,price,number):
        self.name=name
        self.price=price
        self.number=number
    def __str__(self):
        return f'name:{self.name},price:{self.price},number:{self.number}'

    def apply_discount(self):
        return 'depend on product'


class Book(Product):
    def __init__(self,name,price,number,author,pages):
        super().__init__(name,price,number)
        self.author=author
        self.pages=pages
    def __str__(self):
        return f'{super().__str__()},author:{self.author},pages:{self.pages}'
    
    def apply_discount(self):
        return 'no discount'

class Laptop(Product):
    def __init__(self,name,price,number,ram,cpu):
        super().__init__(name,price,number)
        self.ram=ram
        self.cpu=cpu
    def __str__(self):
        return f'{super().__str__()},ram:{self.ram},cpu:{self.cpu}'
    
    def apply_discount(self):
        discount=self.price*(0.05)
        self.price-=discount
        return self.price
    
    
p1=Product('n1',1000,9)
b1=Book('nb',90,2,'a1',76)
l1=Laptop('nl', 5000, 4, 18, 'c1')
lst=[p1,b1,l1]
for i in lst:
    print(i.apply_discount())
    