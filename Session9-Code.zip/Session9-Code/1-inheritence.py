class Product:
    def __init__(self,name,price,category):
        self.name=name
        self.price=price
        self.category=category
    
    def __str__(self):
        return f'name:{self.name},price:{self.price},category:{self.category}'
    
    def apply_discount(self,value):
        if value<0 or value>100:
            print('invalid value')
        else:
            discount=self.price*(value/100)
            self.price-=discount
        return self.price


class ElectronicProduct(Product):
    def __init__(self,name,price,category,brand):
        super().__init__(name, price, category)
        self.brand=brand
    def __str__(self):
        return f'{super().__str__()},barnd:{self.brand}'
    def show_price(self):
        return f'priceeee{self.price}'
    
        
class Laptop(ElectronicProduct):
    def __init__(self,name,price,category,brand,ram,processor):
        super().__init__(name, price, category,brand)
        self.ram=ram
        self.processor=processor
    def __str__(self):
        return f'{super().__str__()},ram:{self.ram},processor:{self.processor}'
    
    def show_price(self):
        return f'show_price: {self.price}'
    
    
l1=Laptop('n1', 14000, 'c50', 'b1', 18, 'p1')
l1.apply_discount(5)
print(l1)
print(l1.show_price())