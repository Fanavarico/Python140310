class Product:
    def __init__(self,name,price,category):
        self.name=name
        self.price=price
        self.category=category
    
    def __str__(self):
        return f'name:{self.name},price:{self.price},category:{self.category}'
    
    def apply_discount(self,value):
        if value<0 or value>100:
            print('invalid value')
        else:
            discount=self.price*(value/100)
            self.price-=discount
        return self.price
    def show_price(self):
        return f'show_price{self.price}'




class ElectronicProduct:
    def __init__(self,brand):
        self.brand=brand
    def __str__(self):
        return f'barnd:{self.brand}'
    def show_price(self):
        return f'priceeee{self.price}'

class Laptop(ElectronicProduct,Product):
    def __init__(self, name, price, category,brand,ram,cpu):
        super().__init__(brand)
        Product.__init__(self,name,price,category)
        self.ram=ram
        self.cpu=cpu
    def __str__(self):
        return f'{Product.__str__(self)},{ElectronicProduct.__str__(self)},ram:{self.ram},cpu:{self.cpu}'


if __name__=='__main__':
    l1=Laptop('n1', 1000, 'c1', 'b1', 12, 'cpu1')
    print(l1)
     