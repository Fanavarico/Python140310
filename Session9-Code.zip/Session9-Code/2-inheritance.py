class Product:
    def __init__(self,name,price,category):
        self.name=name
        self.price=price
        self.category=category
    
    def __str__(self):
        return f'name:{self.name},price:{self.price},category:{self.category}'
    
    def apply_discount(self,value):
        if value<0 or value>100:
            print('invalid value')
        else:
            discount=self.price*(value/100)
            self.price-=discount
        return self.price
class Book(Product):
    pass
class ElectronicProduct(Product):
    pass

b1=Book('nb', 100, 2)
ep=ElectronicProduct('n3', 1000, 'c3')