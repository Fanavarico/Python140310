'''for i in range(1,10):
    print(i)
for i in range(0,10,2):
    print(i)
    
for i in range(10,-1,-1):
    print(i)
 
for j in range(10):
    print(j,end=' ')
s=input('enter : ')
for i in s:
    print(i,end='&')'''
for j in range(10):
    if j==9:
        print(j,end='')
    else:
        print(j,end='&')