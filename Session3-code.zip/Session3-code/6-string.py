s='pythonjavaruby'
#i=s.find('javar',2,11)
i=s.index('z')
print(i)