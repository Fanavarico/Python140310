s='123y'
#print(s[::-1])
#l=len(s)
#print(l)
#print('yt' in s)
#h=s.islower()
#h=s.isupper()
h=s.isdigit()
print(h)
