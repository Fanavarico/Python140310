s=input('enter email :')
i=s.find('@')
#print(s[i+1:])
#print(s[:i])

