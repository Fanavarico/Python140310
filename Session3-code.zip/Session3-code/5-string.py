s=input('enter : ')
c=''
for i in s:
    if i.isdigit():
        
        c=c+i
        
print(c)