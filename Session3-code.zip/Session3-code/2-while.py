i=1
while True:
    print(i)
    i+=1
    if i==30:
        break

