'''for i in range(10):
    if i==5:
        break
    
    print(i)'''
    
for i in range(15):
    if i == 5:
        continue
    elif i==7:
        break
    elif i==10:
        break
    
    
    print(i)
