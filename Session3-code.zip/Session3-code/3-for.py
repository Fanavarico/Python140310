s=input('enter : ')
ch=input('enter char : ')
c=0
for i in s:
    if i==ch:
        c+=1
print(c)

