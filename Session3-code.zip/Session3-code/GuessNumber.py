import random
n=random.randint(100, 200)
#print(n)
for j in range(1,10):
    i=int(input('enter number : '))
    if i<n:
        print(j,'greater')
    elif i>n:
        print(j,'smaller')
    elif i==n:
        print(j,'you won')
        break
    if j==9:
        print('game over')
    
