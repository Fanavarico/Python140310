h=['thursday','friday']
w=['saturday','sunday','monday','tuesday','wedensday']

t=input('enter day :')
if t in w:
    print('go to work ')
else:
    m=int(input('enter money'))
    if t in h and m>2000:
        print('shopping')
    elif t in h and m<=2000:
        print('TV')