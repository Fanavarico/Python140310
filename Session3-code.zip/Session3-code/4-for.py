s=input('enter : ')
#ch=input('enter char : ')
c=0
for i in s:
    if i=='t':
        c+=1
print(c)