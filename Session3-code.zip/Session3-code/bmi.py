h=float(input('enter your hight :'))
w=float(input('enter your weight :'))
bmi=w/(h**2)
if bmi<15:
    c='starving'
elif bmi>=15 and bmi<16:
    c='thin'
elif 16<=bmi<18.5:
    c='under weight'
elif bmi>=18.5 and bmi<25:
    c='normal'
elif bmi>=25 and bmi<30:
    c='over weight'
elif bmi>=30:
    c='fat'
print('your bmi is ',bmi,'you are',c)
