n1=float(input('first :'))
n2=float(input('second :'))

if n1>n2:
    print('max',n1)
    print('min ',n2)
    
else:
    print('max ',n2)
    print('min ',n1)