s=input('enter : ')
c=0
for i in s:
    if i.isdigit():
        i=int(i)
        c+=i
print(c)