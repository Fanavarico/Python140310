s=input('enter : ')
for i in s:
    if i.isdigit():
        print(i)
    

