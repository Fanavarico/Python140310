i=1
while i<=4:
    i+=1
    print(i)
    
    