h=['thursday','friday']
w=['saturday','sunday','monday','tuesday','wedensday']
t=input('enter your day :')
if t in w:
    print('go to work ')
elif t in h:
    m=int(input('enter money: '))
    if m>2000:
        print('shopping')
    elif m<=2000:
        print('TV')
        

